package com.example.app2;

import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String SHARED_AUTHORITY = "com.example.app1.MyProvider";
    private static final String URL = "content://" + SHARED_AUTHORITY + "/shareddata";
    private static final Uri CONTENT_URI = Uri.parse(URL);
    private ListView mLvData;
    private MyAdapter mAdapter;
    private ArrayList<String> mVersions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mLvData = (ListView) findViewById(R.id.listView);
        if (!providerExists(CONTENT_URI)) {
            Toast.makeText(this, "There is no public provider with this authority !",
                    Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Cursor cursor = getContentResolver().query(CONTENT_URI, null, null, null, null);
            if (cursor != null) {
                if (!cursor.moveToFirst()) {
                    Toast.makeText(this, "no data yet", Toast.LENGTH_SHORT).show();
                } else {
                    do {
                        String version = cursor.getString(cursor.getColumnIndex("version"));
                        mVersions.add(version);
                    } while (cursor.moveToNext());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        mAdapter = new MyAdapter(this, mVersions);
        mLvData.setAdapter(mAdapter);
    }

    private boolean providerExists(Uri uri) {
        ProviderInfo pi = getPackageManager().resolveContentProvider(uri.getAuthority(), 0);
        return (pi != null);
    }
}
